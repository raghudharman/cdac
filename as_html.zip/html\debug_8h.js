var debug_8h =
[
    [ "ASSERT", "debug_8h.html#a28301f76c53b643912da7c538f74e2c6", null ],
    [ "__error__", "group__device__api.html#gad3489db107760a81e8a1382fe6ed6d61", null ]
];