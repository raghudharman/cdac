var clb_8c =
[
    [ "CLB_clearFIFOs", "group__clb__api.html#gacf4cc1d21fb0ef6293d1f95a611f1b54", null ],
    [ "CLB_configCounterLoadMatch", "group__clb__api.html#ga7fd72ef8d235d50ffcb0b6783df54ed7", null ],
    [ "CLB_readFIFOs", "group__clb__api.html#gaae759797302f169029f6432eecb96d2d", null ],
    [ "CLB_writeFIFOs", "group__clb__api.html#ga8b069ce92af7256c45e9d613a7ffaf98", null ]
];