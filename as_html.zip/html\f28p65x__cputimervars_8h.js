var f28p65x__cputimervars_8h =
[
    [ "CPUTIMER_VARS", "struct_c_p_u_t_i_m_e_r___v_a_r_s.html", "struct_c_p_u_t_i_m_e_r___v_a_r_s" ],
    [ "ReadCpuTimer0Counter", "f28p65x__cputimervars_8h.html#adc6c0b5670b0b5229826c58309c56830", null ],
    [ "ReadCpuTimer0Period", "f28p65x__cputimervars_8h.html#a925369d3f767097b913219e3f6b0991f", null ],
    [ "ReadCpuTimer1Counter", "f28p65x__cputimervars_8h.html#a0145fb1bc37359d7932af09a1805f3d1", null ],
    [ "ReadCpuTimer1Period", "f28p65x__cputimervars_8h.html#a25929ef1e114fbc5c2b9fb5563d88369", null ],
    [ "ReadCpuTimer2Counter", "f28p65x__cputimervars_8h.html#a24a4a5053f09943aac76265f3859d0d5", null ],
    [ "ReadCpuTimer2Period", "f28p65x__cputimervars_8h.html#a91fd6cae3bdea2b6691297b28237d780", null ],
    [ "ReloadCpuTimer0", "f28p65x__cputimervars_8h.html#a2b059a810ae91f3b44021b7fe5c10ee3", null ],
    [ "ReloadCpuTimer1", "f28p65x__cputimervars_8h.html#a536a8b96dcf7e7a89c2262936497a084", null ],
    [ "ReloadCpuTimer2", "f28p65x__cputimervars_8h.html#a97461baeb4cd3cf6bf8b66d5f56c9a1b", null ],
    [ "StartCpuTimer0", "f28p65x__cputimervars_8h.html#a98358fad4405f518535934bb8b0420af", null ],
    [ "StartCpuTimer1", "f28p65x__cputimervars_8h.html#a018edd11d50b967cdfb852168a843fd8", null ],
    [ "StartCpuTimer2", "f28p65x__cputimervars_8h.html#aa0f5329bb23b2566e86358eca9ed3573", null ],
    [ "StopCpuTimer0", "f28p65x__cputimervars_8h.html#ac4d5a46e949f4dfda25cde6ea4c754a5", null ],
    [ "StopCpuTimer1", "f28p65x__cputimervars_8h.html#a0eb843ef1cc940e64e1b75a023a40bab", null ],
    [ "StopCpuTimer2", "f28p65x__cputimervars_8h.html#adc200976083bb13b49c2674ac042cf9f", null ],
    [ "ConfigCpuTimer", "f28p65x__cputimervars_8h.html#ab9368e14715e9c17a2223c7433fabe73", null ],
    [ "InitCpuTimers", "f28p65x__cputimervars_8h.html#aa23a1f332721d800fa9b232563403609", null ],
    [ "CpuTimer0", "f28p65x__cputimervars_8h.html#ac4d96e0d33fc1ee7a5c22f8a091fcff5", null ],
    [ "CpuTimer1", "f28p65x__cputimervars_8h.html#ab0efabdc64b1ff989ecc7654d34e7894", null ],
    [ "CpuTimer2", "f28p65x__cputimervars_8h.html#ad510e7823bc189dcb96e3b786c3f571e", null ]
];