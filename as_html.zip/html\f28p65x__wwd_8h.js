var f28p65x__wwd_8h =
[
    [ "SCSR_BITS", "struct_s_c_s_r___b_i_t_s.html", "struct_s_c_s_r___b_i_t_s" ],
    [ "SCSR_REG", "union_s_c_s_r___r_e_g.html", "union_s_c_s_r___r_e_g" ],
    [ "WDCNTR_BITS", "struct_w_d_c_n_t_r___b_i_t_s.html", "struct_w_d_c_n_t_r___b_i_t_s" ],
    [ "WDCNTR_REG", "union_w_d_c_n_t_r___r_e_g.html", "union_w_d_c_n_t_r___r_e_g" ],
    [ "WDKEY_BITS", "struct_w_d_k_e_y___b_i_t_s.html", "struct_w_d_k_e_y___b_i_t_s" ],
    [ "WDKEY_REG", "union_w_d_k_e_y___r_e_g.html", "union_w_d_k_e_y___r_e_g" ],
    [ "WDCR_BITS", "struct_w_d_c_r___b_i_t_s.html", "struct_w_d_c_r___b_i_t_s" ],
    [ "WDCR_REG", "union_w_d_c_r___r_e_g.html", "union_w_d_c_r___r_e_g" ],
    [ "WDWCR_BITS", "struct_w_d_w_c_r___b_i_t_s.html", "struct_w_d_w_c_r___b_i_t_s" ],
    [ "WDWCR_REG", "union_w_d_w_c_r___r_e_g.html", "union_w_d_w_c_r___r_e_g" ],
    [ "WD_REGS", "struct_w_d___r_e_g_s.html", "struct_w_d___r_e_g_s" ]
];