var cpu__cla__shared_8h =
[
    [ "motPars", "structmot_pars.html", "structmot_pars" ],
    [ "CLAMP_MACRO", "cpu__cla__shared_8h.html#a6925eb9ee060c5c02717e2be59f75cbd", null ],
    [ "FCL_PI_MACRO", "cpu__cla__shared_8h.html#aa3e3abfda19c1226d8ecae86df428495", null ],
    [ "SETGPIO18_HIGH", "cpu__cla__shared_8h.html#a97beafc516d4962c25663372c657d683", null ],
    [ "SETGPIO18_LOW", "cpu__cla__shared_8h.html#aa0456783f0c25849c5c68fe36f66ecc7", null ],
    [ "cmplxPars_t", "cpu__cla__shared_8h.html#adad64de9ccb22e6152155768468dc27c", null ],
    [ "ctrlPeriod_sec", "cpu__cla__shared_8h.html#aa11975085370ab09d4ee17956e8eb62e", null ],
    [ "D_cpu", "cpu__cla__shared_8h.html#a25172ccb99d0b0980315b78fd6436fe4", null ],
    [ "lsw", "cpu__cla__shared_8h.html#aa5bc47bff65096d4e8341bf3b1645b61", null ],
    [ "mon_pangle", "cpu__cla__shared_8h.html#ab1c3c9b3a1a9bf741c81c8d4a7c135ee", null ],
    [ "pang_prev", "cpu__cla__shared_8h.html#a00c486d692c26d5d9383c618845dc7ca", null ],
    [ "pangle", "cpu__cla__shared_8h.html#a8257323086cd6c6fc018e6ec122e441f", null ],
    [ "pi_iq", "cpu__cla__shared_8h.html#a77abc194fda9cf3de44c44286e10c240", null ],
    [ "Q_cla", "cpu__cla__shared_8h.html#a2b2fb90127c860a224b1c4de03124b2a", null ],
    [ "qep1", "cpu__cla__shared_8h.html#a3dd06b97006886a4fddce6ce6f9ed7fd", null ],
    [ "rg1", "cpu__cla__shared_8h.html#a6a43f495692dc17ef189dfeb9f92385b", null ],
    [ "save_pangle", "cpu__cla__shared_8h.html#a16c5eeab72da9c095398c19a4b7fb37b", null ],
    [ "speedWe", "cpu__cla__shared_8h.html#a5473284b3b4e6b7c93e4a370e206ba9a", null ]
];