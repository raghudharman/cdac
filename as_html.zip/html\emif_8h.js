var emif_8h =
[
    [ "EMIF_ACCPROT0_CPUWRPROT", "group__emif__api.html#ga5380186fee531329a9277daaa9b9bcdd", null ],
    [ "EMIF_ACCPROT0_DMAWRPROT", "group__emif__api.html#ga1f8ce207cc4b489ba142e4cbe01fe13a", null ],
    [ "EMIF_ACCPROT0_FETCHPROT", "group__emif__api.html#gae5b222ec64fae53c6839ed149330cee4", null ],
    [ "EMIF_ACCPROT0_MASK_EMIF1", "group__emif__api.html#gae077845c6d6b6343715c238d1a23f2aa", null ],
    [ "EMIF_ASYNC_CS_CR_MASK", "group__emif__api.html#ga31acaca7ba438c98fdcb9a6b448dd6d6", null ],
    [ "EMIF_ASYNC_INT_AT", "group__emif__api.html#ga921e6c41eaa969d3d7900f315ca6088a", null ],
    [ "EMIF_ASYNC_INT_LT", "group__emif__api.html#ga16e93a8791fe1e8f952bf96b5adc6279", null ],
    [ "EMIF_ASYNC_INT_MASK", "group__emif__api.html#ga25aab63ffc80b3d3dfef20c39a35d118", null ],
    [ "EMIF_ASYNC_INT_WR", "group__emif__api.html#ga625ba52db96503ce842ac70104e66477", null ],
    [ "EMIF_MSEL_KEY", "group__emif__api.html#gaa6357a33125453590c75e6e08ac07f39", null ],
    [ "EMIF_SYNC_SDRAM_CR_MASK", "group__emif__api.html#gad28cb201523ac16851083014fc7c8939", null ],
    [ "EMIF_SYNC_SDRAM_TR_MASK", "group__emif__api.html#ga04cd4a85ccc3c9b0bdc35a07566de7b2", null ],
    [ "EMIF_AsyncCSOffset", "group__emif__api.html#gafb00746b18326a7755d4c2ee9fabe83e", [
      [ "EMIF_ASYNC_CS2_OFFSET", "group__emif__api.html#ggafb00746b18326a7755d4c2ee9fabe83eafbc8a3cbf8ce7d4d7ad6870f6678ef9e", null ],
      [ "EMIF_ASYNC_CS3_OFFSET", "group__emif__api.html#ggafb00746b18326a7755d4c2ee9fabe83ea809a45795a04486175fd5d42c9690019", null ],
      [ "EMIF_ASYNC_CS4_OFFSET", "group__emif__api.html#ggafb00746b18326a7755d4c2ee9fabe83eaddcd8f4ab040e441c1b236940a1a1c85", null ]
    ] ],
    [ "EMIF_AsyncDataWidth", "group__emif__api.html#gabfb3d8a618d103472fb6449db76023a3", [
      [ "EMIF_ASYNC_DATA_WIDTH_8", "group__emif__api.html#ggabfb3d8a618d103472fb6449db76023a3a3f5ae8254cdd4b98b93b0e8dafff7b42", null ],
      [ "EMIF_ASYNC_DATA_WIDTH_16", "group__emif__api.html#ggabfb3d8a618d103472fb6449db76023a3a96e7784b21c2b3663e784a75498a0400", null ],
      [ "EMIF_ASYNC_DATA_WIDTH_32", "group__emif__api.html#ggabfb3d8a618d103472fb6449db76023a3ab033c31d86a6d16f9b9e1fdcfd1efbce", null ]
    ] ],
    [ "EMIF_AsyncMode", "group__emif__api.html#ga546ace043545f4954270dd11280c0384", [
      [ "EMIF_ASYNC_STROBE_MODE", "group__emif__api.html#gga546ace043545f4954270dd11280c0384a7a134369434a0641cadb171df5ea6480", null ],
      [ "EMIF_ASYNC_NORMAL_MODE", "group__emif__api.html#gga546ace043545f4954270dd11280c0384aeb0c7017eb1b07859e310a4f77f65959", null ]
    ] ],
    [ "EMIF_AsyncWaitPolarity", "group__emif__api.html#gaea70703edb00d37e0b942f549fff63d7", [
      [ "EMIF_ASYNC_WAIT_POLARITY_LOW", "group__emif__api.html#ggaea70703edb00d37e0b942f549fff63d7ac4bcf6fc1972c2b220d944afb28e2318", null ],
      [ "EMIF_ASYNC_WAIT_POLARITY_HIGH", "group__emif__api.html#ggaea70703edb00d37e0b942f549fff63d7a8972850ba57dcde99937b5143c5bdf20", null ]
    ] ],
    [ "EMIF_ControllerSelect", "group__emif__api.html#ga422248d9680305b98cc15201c47d6479", [
      [ "EMIF_CONTROLLER_CPU1_NG", "group__emif__api.html#gga422248d9680305b98cc15201c47d6479a03706ac3ba47181f2cc029c746b96466", null ],
      [ "EMIF_CONTROLLER_CPU1_G", "group__emif__api.html#gga422248d9680305b98cc15201c47d6479a83622a47bc650edd9cc17879d25e1294", null ],
      [ "EMIF_CONTROLLER_CPU2_G", "group__emif__api.html#gga422248d9680305b98cc15201c47d6479a111f1bc121452c612f974288a5e5442c", null ],
      [ "EMIF_CONTROLLER_CPU1_NG2", "group__emif__api.html#gga422248d9680305b98cc15201c47d6479a8a33b5ecdbd8199ee810269d381de2af", null ]
    ] ],
    [ "EMIF_SyncBank", "group__emif__api.html#ga626c2bb06e30d56919df337a57fd479e", [
      [ "EMIF_SYNC_BANK_1", "group__emif__api.html#gga626c2bb06e30d56919df337a57fd479ea1053817758f8058a206cae9501d706ec", null ],
      [ "EMIF_SYNC_BANK_2", "group__emif__api.html#gga626c2bb06e30d56919df337a57fd479ea896572a7d48bb76c5da518d4241351c2", null ],
      [ "EMIF_SYNC_BANK_4", "group__emif__api.html#gga626c2bb06e30d56919df337a57fd479ea9f184f7fb48246b338fe8fa837613630", null ]
    ] ],
    [ "EMIF_SyncCASLatency", "group__emif__api.html#ga3000d82428c9cfa74ccdaa0ed34d3739", [
      [ "EMIF_SYNC_CAS_LAT_2", "group__emif__api.html#gga3000d82428c9cfa74ccdaa0ed34d3739ae7ffe259582a5ca88da53e9ea9b9a77d", null ],
      [ "EMIF_SYNC_CAS_LAT_3", "group__emif__api.html#gga3000d82428c9cfa74ccdaa0ed34d3739af987bd321a374f4b287bac9f5e877c9b", null ]
    ] ],
    [ "EMIF_SyncNarrowMode", "group__emif__api.html#gaa5f727b71e281f321a30b9468ad8ba98", [
      [ "EMIF_SYNC_NARROW_MODE_TRUE", "group__emif__api.html#ggaa5f727b71e281f321a30b9468ad8ba98a168d8e04840c2f17176c387bb19d9ecb", null ],
      [ "EMIF_SYNC_NARROW_MODE_FALSE", "group__emif__api.html#ggaa5f727b71e281f321a30b9468ad8ba98aaa21075a19be9ac1efaa93c639ccc90b", null ]
    ] ],
    [ "EMIF_SyncPageSize", "group__emif__api.html#gab224dd56431737729f79eda4c891d34a", [
      [ "EMIF_SYNC_COLUMN_WIDTH_8", "group__emif__api.html#ggab224dd56431737729f79eda4c891d34aad9f7a3ea8ff27d2beb4d289febf3a480", null ],
      [ "EMIF_SYNC_COLUMN_WIDTH_9", "group__emif__api.html#ggab224dd56431737729f79eda4c891d34aa59053df6badf7034aea7a8fa8aff61d2", null ],
      [ "EMIF_SYNC_COLUMN_WIDTH_10", "group__emif__api.html#ggab224dd56431737729f79eda4c891d34aabbd875691d25de7ffd03d4b9bf4aa8f7", null ],
      [ "EMIF_SYNC_COLUMN_WIDTH_11", "group__emif__api.html#ggab224dd56431737729f79eda4c891d34aa0846f825c1bc853df761b4c62eccd6bd", null ]
    ] ],
    [ "EMIF_clearAsyncInterruptStatus", "group__emif__api.html#gab9aaae14fd09b40fce1184ea41252585", null ],
    [ "EMIF_commitAccessConfig", "group__emif__api.html#ga63198ad4642893ccb22b3663fac86332", null ],
    [ "EMIF_disableAsyncExtendedWait", "group__emif__api.html#ga9939cff1eb79fcc7cfc0211fdf56edca", null ],
    [ "EMIF_disableAsyncInterrupt", "group__emif__api.html#gaa76f477f3b4a39f82357ba10356b7486", null ],
    [ "EMIF_disableSyncPowerDown", "group__emif__api.html#ga31358fd299439f9a42d8400f0b18fe77", null ],
    [ "EMIF_disableSyncRefreshInPowerDown", "group__emif__api.html#ga11b97ef92de2464bd9c559ccb70978ac", null ],
    [ "EMIF_disableSyncSelfRefresh", "group__emif__api.html#ga1db20179bdfc2d0eeef8d8ca629a42d6", null ],
    [ "EMIF_enableAsyncExtendedWait", "group__emif__api.html#ga2c0b8be1afe52932105f78362b3b0012", null ],
    [ "EMIF_enableAsyncInterrupt", "group__emif__api.html#gafd2a38d4657816337e624a6729cc83a3", null ],
    [ "EMIF_enableSyncPowerDown", "group__emif__api.html#ga61dfa4a28872964da681ce43be70ae99", null ],
    [ "EMIF_enableSyncRefreshInPowerDown", "group__emif__api.html#gaf92b23f3aac4db49256ee0e9a4ada9ad", null ],
    [ "EMIF_enableSyncSelfRefresh", "group__emif__api.html#gaecba9e6d22c8005e3afd58804010b7f4", null ],
    [ "EMIF_getAsyncInterruptStatus", "group__emif__api.html#gaf2886da183be07678fe17b90de82293f", null ],
    [ "EMIF_getSyncTotalAccesses", "group__emif__api.html#gad4c152f83b4e36cd14582a2d4a860426", null ],
    [ "EMIF_getSyncTotalActivateAccesses", "group__emif__api.html#ga5bd73b2d1f9b4b6efb0022df26640e5a", null ],
    [ "EMIF_lockAccessConfig", "group__emif__api.html#ga4fdc54714b1c5e006d93b03d1b5a2559", null ],
    [ "EMIF_selectController", "group__emif__api.html#gac59785eaf8949d33454ff53c8939ddc7", null ],
    [ "EMIF_setAccessProtection", "group__emif__api.html#gaa8d18441f143f286ae5bb04838339dfc", null ],
    [ "EMIF_setAsyncDataBusWidth", "group__emif__api.html#ga635673f91c658c672c5d998e9e82d56c", null ],
    [ "EMIF_setAsyncMaximumWaitCycles", "group__emif__api.html#ga8ff456609afa4b0f794a73b2773adfad", null ],
    [ "EMIF_setAsyncMode", "group__emif__api.html#gaa2be0c283e4dec372645d885759b460d", null ],
    [ "EMIF_setAsyncTimingParams", "group__emif__api.html#ga4e140cfbdfc01c581ed6ad31d3a80af9", null ],
    [ "EMIF_setAsyncWaitPolarity", "group__emif__api.html#gac01890394b7d440c8cfa947f1415e2cb", null ],
    [ "EMIF_setSyncMemoryConfig", "group__emif__api.html#ga7e6f27bbc56def93700b48004920b804", null ],
    [ "EMIF_setSyncRefreshRate", "group__emif__api.html#ga793529ab875c531d5c74eed5b72201b6", null ],
    [ "EMIF_setSyncSelfRefreshExitTmng", "group__emif__api.html#ga7101a7ed55005dd84180fcb6284ccb3a", null ],
    [ "EMIF_setSyncTimingParams", "group__emif__api.html#gab449d7094aec34f121926b2d95cffc73", null ],
    [ "EMIF_unlockAccessConfig", "group__emif__api.html#gaf39252665e52004c4317e5277ce783e7", null ]
];