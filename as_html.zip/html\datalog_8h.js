var datalog_8h =
[
    [ "DATA_LOG_BUFF_NUM", "group___d_a_t_a_l_o_g.html#gaba9a2d579e4c1924b2c0bb2e8b5fe435", null ],
    [ "DATA_LOG_BUFF_SIZE", "group___d_a_t_a_l_o_g.html#gabfe0510083a35a032b26bf78f9ba0951", null ],
    [ "DATALOG_DEFAULTS", "group___d_a_t_a_l_o_g.html#ga947cec97dcbc8671010bf09298de29d5", null ],
    [ "DLOG_BURST_SIZE", "group___d_a_t_a_l_o_g.html#gaa6f321186d1d8f11edd941c5caf2e00d", null ],
    [ "DLOG_TRANSFER_SIZE", "group___d_a_t_a_l_o_g.html#ga6639d20a90565a6bbc1480f6882b062d", null ],
    [ "DATALOG_Handle", "group___d_a_t_a_l_o_g.html#ga3e53e61bd9966fd69cb247dd817871b1", null ],
    [ "DATALOG_Obj", "group___d_a_t_a_l_o_g.html#ga574bcdbe30cb56cd05038aabe447c6e6", null ],
    [ "DATALOG_init", "group___d_a_t_a_l_o_g.html#gac9336e22182df42434e81252f206cb06", null ],
    [ "DATALOG_update", "group___d_a_t_a_l_o_g.html#gac9e7e72b589e4c76c1aedf74609c1127", null ],
    [ "DATALOG_updateWithDMA", "group___d_a_t_a_l_o_g.html#ga6b325dc022a86625ac6925d2a32fe13d", null ],
    [ "datalog", "group___d_a_t_a_l_o_g.html#ga02ea6a4c6623443af01a9a24ec8551fe", null ],
    [ "datalogBuff1", "group___d_a_t_a_l_o_g.html#ga8c7e8e64366f7434ea72898d8c6c9846", null ],
    [ "datalogBuff2", "group___d_a_t_a_l_o_g.html#ga128324b5fc438065003d63d8819f21c9", null ],
    [ "datalogBuff3", "group___d_a_t_a_l_o_g.html#gafd0bce626574cd628ae2f2cb3a2fac84", null ],
    [ "datalogBuff4", "group___d_a_t_a_l_o_g.html#gabe86fa947cfcd7fc90488b114133ad75", null ],
    [ "datalogHandle", "group___d_a_t_a_l_o_g.html#gae33894605b575d67601cf18eef4bd61e", null ]
];