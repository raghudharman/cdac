var f28p65x__hrpwmcal_8h =
[
    [ "HRPWR_BITS", "struct_h_r_p_w_r___b_i_t_s.html", "struct_h_r_p_w_r___b_i_t_s" ],
    [ "HRPWR_REG", "union_h_r_p_w_r___r_e_g.html", "union_h_r_p_w_r___r_e_g" ],
    [ "HRMSTEP_BITS", "struct_h_r_m_s_t_e_p___b_i_t_s.html", "struct_h_r_m_s_t_e_p___b_i_t_s" ],
    [ "HRMSTEP_REG", "union_h_r_m_s_t_e_p___r_e_g.html", "union_h_r_m_s_t_e_p___r_e_g" ],
    [ "HRPWMCAL_REGS", "struct_h_r_p_w_m_c_a_l___r_e_g_s.html", "struct_h_r_p_w_m_c_a_l___r_e_g_s" ]
];