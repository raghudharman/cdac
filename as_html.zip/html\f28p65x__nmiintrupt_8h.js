var f28p65x__nmiintrupt_8h =
[
    [ "NMICFG_BITS", "struct_n_m_i_c_f_g___b_i_t_s.html", "struct_n_m_i_c_f_g___b_i_t_s" ],
    [ "NMICFG_REG", "union_n_m_i_c_f_g___r_e_g.html", "union_n_m_i_c_f_g___r_e_g" ],
    [ "NMIFLG_BITS", "struct_n_m_i_f_l_g___b_i_t_s.html", "struct_n_m_i_f_l_g___b_i_t_s" ],
    [ "NMIFLG_REG", "union_n_m_i_f_l_g___r_e_g.html", "union_n_m_i_f_l_g___r_e_g" ],
    [ "NMIFLGCLR_BITS", "struct_n_m_i_f_l_g_c_l_r___b_i_t_s.html", "struct_n_m_i_f_l_g_c_l_r___b_i_t_s" ],
    [ "NMIFLGCLR_REG", "union_n_m_i_f_l_g_c_l_r___r_e_g.html", "union_n_m_i_f_l_g_c_l_r___r_e_g" ],
    [ "NMIFLGFRC_BITS", "struct_n_m_i_f_l_g_f_r_c___b_i_t_s.html", "struct_n_m_i_f_l_g_f_r_c___b_i_t_s" ],
    [ "NMIFLGFRC_REG", "union_n_m_i_f_l_g_f_r_c___r_e_g.html", "union_n_m_i_f_l_g_f_r_c___r_e_g" ],
    [ "NMISHDFLG_BITS", "struct_n_m_i_s_h_d_f_l_g___b_i_t_s.html", "struct_n_m_i_s_h_d_f_l_g___b_i_t_s" ],
    [ "NMISHDFLG_REG", "union_n_m_i_s_h_d_f_l_g___r_e_g.html", "union_n_m_i_s_h_d_f_l_g___r_e_g" ],
    [ "ERRORSTS_BITS", "struct_e_r_r_o_r_s_t_s___b_i_t_s.html", "struct_e_r_r_o_r_s_t_s___b_i_t_s" ],
    [ "ERRORSTS_REG", "union_e_r_r_o_r_s_t_s___r_e_g.html", "union_e_r_r_o_r_s_t_s___r_e_g" ],
    [ "ERRORSTSCLR_BITS", "struct_e_r_r_o_r_s_t_s_c_l_r___b_i_t_s.html", "struct_e_r_r_o_r_s_t_s_c_l_r___b_i_t_s" ],
    [ "ERRORSTSCLR_REG", "union_e_r_r_o_r_s_t_s_c_l_r___r_e_g.html", "union_e_r_r_o_r_s_t_s_c_l_r___r_e_g" ],
    [ "ERRORSTSFRC_BITS", "struct_e_r_r_o_r_s_t_s_f_r_c___b_i_t_s.html", "struct_e_r_r_o_r_s_t_s_f_r_c___b_i_t_s" ],
    [ "ERRORSTSFRC_REG", "union_e_r_r_o_r_s_t_s_f_r_c___r_e_g.html", "union_e_r_r_o_r_s_t_s_f_r_c___r_e_g" ],
    [ "ERRORCTL_BITS", "struct_e_r_r_o_r_c_t_l___b_i_t_s.html", "struct_e_r_r_o_r_c_t_l___b_i_t_s" ],
    [ "ERRORCTL_REG", "union_e_r_r_o_r_c_t_l___r_e_g.html", "union_e_r_r_o_r_c_t_l___r_e_g" ],
    [ "ERRORLOCK_BITS", "struct_e_r_r_o_r_l_o_c_k___b_i_t_s.html", "struct_e_r_r_o_r_l_o_c_k___b_i_t_s" ],
    [ "ERRORLOCK_REG", "union_e_r_r_o_r_l_o_c_k___r_e_g.html", "union_e_r_r_o_r_l_o_c_k___r_e_g" ],
    [ "NMI_INTRUPT_REGS", "struct_n_m_i___i_n_t_r_u_p_t___r_e_g_s.html", "struct_n_m_i___i_n_t_r_u_p_t___r_e_g_s" ]
];