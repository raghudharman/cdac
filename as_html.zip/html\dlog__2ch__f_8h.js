var dlog__2ch__f_8h =
[
    [ "DLOG_2CH_F", "struct_d_l_o_g__2_c_h___f.html", "struct_d_l_o_g__2_c_h___f" ],
    [ "DLOG_2CH_F_FUNC", "dlog__2ch__f_8h.html#a4dd171cfdc22feb25c21dbd6d9cb2207", null ],
    [ "DLOG_2CH_F_init", "dlog__2ch__f_8h.html#aefc87cd32b84939424e00e395e850ca0", null ]
];