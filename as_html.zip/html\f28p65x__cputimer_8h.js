var f28p65x__cputimer_8h =
[
    [ "TIM_BITS", "struct_t_i_m___b_i_t_s.html", "struct_t_i_m___b_i_t_s" ],
    [ "TIM_REG", "union_t_i_m___r_e_g.html", "union_t_i_m___r_e_g" ],
    [ "PRD_BITS", "struct_p_r_d___b_i_t_s.html", "struct_p_r_d___b_i_t_s" ],
    [ "PRD_REG", "union_p_r_d___r_e_g.html", "union_p_r_d___r_e_g" ],
    [ "TCR_BITS", "struct_t_c_r___b_i_t_s.html", "struct_t_c_r___b_i_t_s" ],
    [ "TCR_REG", "union_t_c_r___r_e_g.html", "union_t_c_r___r_e_g" ],
    [ "TPR_BITS", "struct_t_p_r___b_i_t_s.html", "struct_t_p_r___b_i_t_s" ],
    [ "TPR_REG", "union_t_p_r___r_e_g.html", "union_t_p_r___r_e_g" ],
    [ "TPRH_BITS", "struct_t_p_r_h___b_i_t_s.html", "struct_t_p_r_h___b_i_t_s" ],
    [ "TPRH_REG", "union_t_p_r_h___r_e_g.html", "union_t_p_r_h___r_e_g" ],
    [ "CPUTIMER_REGS", "struct_c_p_u_t_i_m_e_r___r_e_g_s.html", "struct_c_p_u_t_i_m_e_r___r_e_g_s" ]
];