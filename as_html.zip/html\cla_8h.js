var cla_8h =
[
    [ "CLA_NUM_EOT_INTERRUPTS", "group__cla__api.html#ga1cbb35dc426c73cb79d2cbdf689fc7ef", null ],
    [ "CLA_TASKFLAG_1", "group__cla__api.html#ga648c9ee38b23c8222bbd699b63d92308", null ],
    [ "CLA_TASKFLAG_2", "group__cla__api.html#ga08f93464f973e0d6d0734ac7ec55839a", null ],
    [ "CLA_TASKFLAG_3", "group__cla__api.html#ga0f01ca259964754a53599379ca529ce1", null ],
    [ "CLA_TASKFLAG_4", "group__cla__api.html#gaef8a1fda579e5e1f3756e869a42695f5", null ],
    [ "CLA_TASKFLAG_5", "group__cla__api.html#gafe22148b8125e6757e7990b44d13b477", null ],
    [ "CLA_TASKFLAG_6", "group__cla__api.html#ga02f900775e3f258624b33eea9d4c03df", null ],
    [ "CLA_TASKFLAG_7", "group__cla__api.html#ga38c802204df64a49a9735a36040f07fd", null ],
    [ "CLA_TASKFLAG_8", "group__cla__api.html#ga888a24d4eb1e07f1bb340117c897a3c3", null ],
    [ "CLA_TASKFLAG_ALL", "group__cla__api.html#gad3e074005a99d4914bfc61906f450b51", null ],
    [ "CLA_TaskNumber", "group__cla__api.html#ga74b35d7ed82ad63af912657d121c6265", [
      [ "CLA_TASK_1", "group__cla__api.html#gga74b35d7ed82ad63af912657d121c6265a36a3564f95dc6ed95d5be56ec6a086a7", null ],
      [ "CLA_TASK_2", "group__cla__api.html#gga74b35d7ed82ad63af912657d121c6265a9faeb9d1d2bdae3a4dc9ed927a7811ff", null ],
      [ "CLA_TASK_3", "group__cla__api.html#gga74b35d7ed82ad63af912657d121c6265a5f52f86d9f4151375cfd6c0032f669a0", null ],
      [ "CLA_TASK_4", "group__cla__api.html#gga74b35d7ed82ad63af912657d121c6265acecbfa58a451eedfd39ff44931719a66", null ],
      [ "CLA_TASK_5", "group__cla__api.html#gga74b35d7ed82ad63af912657d121c6265a03bc7da466942c430afce80c230eb1a5", null ],
      [ "CLA_TASK_6", "group__cla__api.html#gga74b35d7ed82ad63af912657d121c6265ac63fd1d500b6e626f101b49838877a8e", null ],
      [ "CLA_TASK_7", "group__cla__api.html#gga74b35d7ed82ad63af912657d121c6265a051f660f1dc3712db69204fbb6638df2", null ],
      [ "CLA_TASK_8", "group__cla__api.html#gga74b35d7ed82ad63af912657d121c6265a5375dd6366ba1e22acf6ec6a2b16ba1b", null ]
    ] ]
];