var dcc_8c =
[
    [ "DCC_continuousMonitor", "group__dcc__api.html#ga9d0cea773d6d05b71b5eb1d9ff56e05a", null ],
    [ "DCC_measureClockFrequency", "group__dcc__api.html#gadc29cccc1525f8029b83b9d2ffeba37e", null ],
    [ "DCC_verifyClockFrequency", "group__dcc__api.html#ga337c8343635bbae9e6f52f382c7f6f10", null ]
];