var f28p65x__lcm_8h =
[
    [ "LCM_REVISION_BITS", "struct_l_c_m___r_e_v_i_s_i_o_n___b_i_t_s.html", "struct_l_c_m___r_e_v_i_s_i_o_n___b_i_t_s" ],
    [ "LCM_REVISION_REG", "union_l_c_m___r_e_v_i_s_i_o_n___r_e_g.html", "union_l_c_m___r_e_v_i_s_i_o_n___r_e_g" ],
    [ "LCM_CONTROL_BITS", "struct_l_c_m___c_o_n_t_r_o_l___b_i_t_s.html", "struct_l_c_m___c_o_n_t_r_o_l___b_i_t_s" ],
    [ "LCM_CONTROL_REG", "union_l_c_m___c_o_n_t_r_o_l___r_e_g.html", "union_l_c_m___c_o_n_t_r_o_l___r_e_g" ],
    [ "LCM_STATUS_BITS", "struct_l_c_m___s_t_a_t_u_s___b_i_t_s.html", "struct_l_c_m___s_t_a_t_u_s___b_i_t_s" ],
    [ "LCM_STATUS_REG", "union_l_c_m___s_t_a_t_u_s___r_e_g.html", "union_l_c_m___s_t_a_t_u_s___r_e_g" ],
    [ "LCM_STATUS_CLEAR_BITS", "struct_l_c_m___s_t_a_t_u_s___c_l_e_a_r___b_i_t_s.html", "struct_l_c_m___s_t_a_t_u_s___c_l_e_a_r___b_i_t_s" ],
    [ "LCM_STATUS_CLEAR_REG", "union_l_c_m___s_t_a_t_u_s___c_l_e_a_r___r_e_g.html", "union_l_c_m___s_t_a_t_u_s___c_l_e_a_r___r_e_g" ],
    [ "PARITY_TEST_BITS", "struct_p_a_r_i_t_y___t_e_s_t___b_i_t_s.html", "struct_p_a_r_i_t_y___t_e_s_t___b_i_t_s" ],
    [ "PARITY_TEST_REG", "union_p_a_r_i_t_y___t_e_s_t___r_e_g.html", "union_p_a_r_i_t_y___t_e_s_t___r_e_g" ],
    [ "LCM_LOCK_BITS", "struct_l_c_m___l_o_c_k___b_i_t_s.html", "struct_l_c_m___l_o_c_k___b_i_t_s" ],
    [ "LCM_LOCK_REG", "union_l_c_m___l_o_c_k___r_e_g.html", "union_l_c_m___l_o_c_k___r_e_g" ],
    [ "LCM_COMMIT_BITS", "struct_l_c_m___c_o_m_m_i_t___b_i_t_s.html", "struct_l_c_m___c_o_m_m_i_t___b_i_t_s" ],
    [ "LCM_COMMIT_REG", "union_l_c_m___c_o_m_m_i_t___r_e_g.html", "union_l_c_m___c_o_m_m_i_t___r_e_g" ],
    [ "LCM_REGS", "struct_l_c_m___r_e_g_s.html", "struct_l_c_m___r_e_g_s" ],
    [ "LCMCPU2DMA1Regs", "f28p65x__lcm_8h.html#aadbf3ee1f6d2a9ae4750506f256727f6", null ],
    [ "LCMCPU2Regs", "f28p65x__lcm_8h.html#ade5e3bb35f00011460ade33b8a5fe77c", null ]
];