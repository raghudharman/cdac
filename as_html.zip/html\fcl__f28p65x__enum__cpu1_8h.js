var fcl__f28p65x__enum__cpu1_8h =
[
    [ "MotorRunStop_e", "fcl__f28p65x__enum__cpu1_8h.html#aab06e64eba633e28df60649f7412c076", [
      [ "MOTOR_STOP", "fcl__f28p65x__enum__cpu1_8h.html#aab06e64eba633e28df60649f7412c076aee6f27e90b9bf054096e96ae6a9f04f7", null ],
      [ "MOTOR_RUN", "fcl__f28p65x__enum__cpu1_8h.html#aab06e64eba633e28df60649f7412c076a71641b416a7ffcbbc23072f9ac744b3f", null ]
    ] ]
];