var f28p65x__spi_8h =
[
    [ "SPICCR_BITS", "struct_s_p_i_c_c_r___b_i_t_s.html", "struct_s_p_i_c_c_r___b_i_t_s" ],
    [ "SPICCR_REG", "union_s_p_i_c_c_r___r_e_g.html", "union_s_p_i_c_c_r___r_e_g" ],
    [ "SPICTL_BITS", "struct_s_p_i_c_t_l___b_i_t_s.html", "struct_s_p_i_c_t_l___b_i_t_s" ],
    [ "SPICTL_REG", "union_s_p_i_c_t_l___r_e_g.html", "union_s_p_i_c_t_l___r_e_g" ],
    [ "SPISTS_BITS", "struct_s_p_i_s_t_s___b_i_t_s.html", "struct_s_p_i_s_t_s___b_i_t_s" ],
    [ "SPISTS_REG", "union_s_p_i_s_t_s___r_e_g.html", "union_s_p_i_s_t_s___r_e_g" ],
    [ "SPIBRR_BITS", "struct_s_p_i_b_r_r___b_i_t_s.html", "struct_s_p_i_b_r_r___b_i_t_s" ],
    [ "SPIBRR_REG", "union_s_p_i_b_r_r___r_e_g.html", "union_s_p_i_b_r_r___r_e_g" ],
    [ "SPIFFTX_BITS", "struct_s_p_i_f_f_t_x___b_i_t_s.html", "struct_s_p_i_f_f_t_x___b_i_t_s" ],
    [ "SPIFFTX_REG", "union_s_p_i_f_f_t_x___r_e_g.html", "union_s_p_i_f_f_t_x___r_e_g" ],
    [ "SPIFFRX_BITS", "struct_s_p_i_f_f_r_x___b_i_t_s.html", "struct_s_p_i_f_f_r_x___b_i_t_s" ],
    [ "SPIFFRX_REG", "union_s_p_i_f_f_r_x___r_e_g.html", "union_s_p_i_f_f_r_x___r_e_g" ],
    [ "SPIFFCT_BITS", "struct_s_p_i_f_f_c_t___b_i_t_s.html", "struct_s_p_i_f_f_c_t___b_i_t_s" ],
    [ "SPIFFCT_REG", "union_s_p_i_f_f_c_t___r_e_g.html", "union_s_p_i_f_f_c_t___r_e_g" ],
    [ "SPIPRI_BITS", "struct_s_p_i_p_r_i___b_i_t_s.html", "struct_s_p_i_p_r_i___b_i_t_s" ],
    [ "SPIPRI_REG", "union_s_p_i_p_r_i___r_e_g.html", "union_s_p_i_p_r_i___r_e_g" ],
    [ "SPI_REGS", "struct_s_p_i___r_e_g_s.html", "struct_s_p_i___r_e_g_s" ]
];