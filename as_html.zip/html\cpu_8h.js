var cpu_8h =
[
    [ "DINT", "cpu_8h.html#a058e7dbf59195ee615d22066fbdd844b", null ],
    [ "DRTM", "cpu_8h.html#aa1af72313e025548b3b9ce6930ea8e26", null ],
    [ "EALLOW", "cpu_8h.html#a1a95377ebb4695a49196cd666e26d97d", null ],
    [ "EDIS", "cpu_8h.html#a4b430256ca8934310dac586331dd358f", null ],
    [ "EINT", "cpu_8h.html#aedda579089c56c5a0df23a0cd47f53a1", null ],
    [ "ERTM", "cpu_8h.html#a961fad1dc1a245ade76d1f7000f6f16f", null ],
    [ "ESTOP0", "cpu_8h.html#a24ae3a5f12943b9a48c5ca989134936d", null ],
    [ "ESTOP1", "cpu_8h.html#af954c6627568ff23d554afbeecf1b900", null ],
    [ "IDLE", "cpu_8h.html#a9c21a7caee326d7803b94ae1952b27ca", null ],
    [ "NOP", "cpu_8h.html#a700f88377bf36711b711f69b06c52f5d", null ],
    [ "__eallow", "cpu_8h.html#abdfbf4ee1abccf525051591b25476eb6", null ],
    [ "__edis", "cpu_8h.html#a4aac640229527c5188b65a406a097832", null ],
    [ "IER", "cpu_8h.html#a036e6b1865b5dae17ba36ad3936b43df", null ],
    [ "IFR", "cpu_8h.html#a874bb28ee73428bd23a6ad07a8e011e4", null ]
];