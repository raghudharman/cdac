var f28p65x__otp_8h =
[
    [ "UID_REGS", "struct_u_i_d___r_e_g_s.html", "struct_u_i_d___r_e_g_s" ],
    [ "UidRegs", "f28p65x__otp_8h.html#a89717a07167cce2283789695dfb120b1", null ]
];