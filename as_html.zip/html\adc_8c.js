var adc_8c =
[
    [ "ADC_getINLTrimOTPLoc", "adc_8c.html#aaddad2090368cc6a7a3b0eda7b9f8bf1", null ],
    [ "ADC_getOffsetTrimOTPLoc", "adc_8c.html#afb864a903026d6c2d359bebe5a63bc78", null ],
    [ "TI_OTP_DEV_KEY", "adc_8c.html#a93b118082ce2688cd8ec7f392104f92c", null ],
    [ "TI_OTP_DEV_PRG_KEY", "adc_8c.html#ad4582071b8a161f878fdda03b2e7d50e", null ],
    [ "ADC_configureRepeater", "group__adc__api.html#ga4a3111e591fb1bc4bb1d40487aff721f", null ],
    [ "ADC_setINLTrim", "group__adc__api.html#ga245251ff514fae5b6959e78842bec621", null ],
    [ "ADC_setMode", "group__adc__api.html#gac6b5f4a6e28b845462cb44d00889a6f9", null ],
    [ "ADC_setOffsetTrim", "group__adc__api.html#gabe0d15283495abce50c21eb97a8491a4", null ],
    [ "ADC_setPPBTripLimits", "group__adc__api.html#ga378cb44d8b8674121e44de0acf48006f", null ],
    [ "ADC_setupSOCRefloChannel", "group__adc__api.html#ga82811db076d3d59caa26e85fe3f9e4a9", null ],
    [ "ADC_setVREF", "group__adc__api.html#gabc9c09c11263685170ed7d88dd36f9e4", null ]
];