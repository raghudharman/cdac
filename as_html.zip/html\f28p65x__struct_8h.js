var f28p65x__struct_8h =
[
    [ "MAX_ADC", "f28p65x__struct_8h.html#aec2426c8f9412cf841cdfd2a4b88a783", null ],
    [ "MAX_CPUTIMER", "f28p65x__struct_8h.html#ad5ce842997931fe1517171c8636f68d5", null ],
    [ "MAX_ECAP", "f28p65x__struct_8h.html#a1715ed2ef1a000184e854400e2251180", null ],
    [ "MAX_EPWM", "f28p65x__struct_8h.html#a8bcad37968cfccdc2f2f82a038897eb8", null ],
    [ "MAX_EQEP", "f28p65x__struct_8h.html#ae56d1634e1f944b5eb14d3404bc5a36a", null ],
    [ "MAX_I2C", "f28p65x__struct_8h.html#a19979acef74788d5b757525ccb43c797", null ],
    [ "MAX_MCBSP", "f28p65x__struct_8h.html#aaa56d1116183532e7e009dbaef7647f1", null ],
    [ "MAX_SCI", "f28p65x__struct_8h.html#afdf3c10f14f6e87efa48d5b96e422d6a", null ],
    [ "MAX_SDFM", "f28p65x__struct_8h.html#aa188e9e8f189621d5e12d96271eadc55", null ],
    [ "MAX_SPI", "f28p65x__struct_8h.html#ae4250b12c1840abeaf61b709aaf60d48", null ],
    [ "MAX_TRIPSEL", "f28p65x__struct_8h.html#a2b5dcf31c461f3b3451ce49cd5792bf6", null ],
    [ "ADC", "f28p65x__struct_8h.html#a3510e352629296b5760d3d703487850e", null ],
    [ "CPUTIMER", "f28p65x__struct_8h.html#ae815ed184ba750c9ca705a8a9408a014", null ],
    [ "ECAP", "f28p65x__struct_8h.html#a259fd6904cc63fd72406b92605fd41fb", null ],
    [ "EPWM", "f28p65x__struct_8h.html#ab8e144ee416bc4fe6e1f64755cdaab0b", null ],
    [ "EQEP", "f28p65x__struct_8h.html#a2755753f1fd0fe05b9b5fa8e5f054a31", null ],
    [ "I2C", "f28p65x__struct_8h.html#a048d35185976aa6d30b0b40800a96ced", null ],
    [ "SDFM", "f28p65x__struct_8h.html#abdf6f1559b3cfffd572e1b8aa524164b", null ],
    [ "SPI", "f28p65x__struct_8h.html#aceb254bbc495e0688e7fc2360636a282", null ],
    [ "TRIP_SEL", "f28p65x__struct_8h.html#a9416657d4639d32f6c27213bf9973ef3", null ]
];