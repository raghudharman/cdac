var clarke_8h =
[
    [ "CLARKE", "struct_c_l_a_r_k_e.html", "struct_c_l_a_r_k_e" ],
    [ "CLARKE1_MACRO", "clarke_8h.html#a25283fe436d90029b047562f7fdb1b0f", null ],
    [ "CLARKE_DEFAULTS", "clarke_8h.html#a29e5e5a58c6502e6a8d2d507e4569781", null ],
    [ "CLARKE_MACRO", "clarke_8h.html#a88599cb7d3848b677ae7b1fd86020f5f", null ],
    [ "ONEbySQRT3", "clarke_8h.html#a708e0b47ca3f097ea22b3f20069a130f", null ],
    [ "runClarke", "clarke_8h.html#af6dc5e55cab391eb7c1d2a5cb7abd688", null ],
    [ "runClarke1", "clarke_8h.html#a715c83e8f4359291258f56504bc96f07", null ]
];