var dma_8c =
[
    [ "DMA_configAddresses", "group__dma__api.html#ga6ce0b2e96a07ac5ece62f8dff7a61ad2", null ],
    [ "DMA_configBurst", "group__dma__api.html#ga2439c8b8c65376c649965a180166e0d9", null ],
    [ "DMA_configChannel", "group__dma__api.html#gace97e0ecaa35c4ba7e8978f24b0b32a6", null ],
    [ "DMA_configMode", "group__dma__api.html#ga60e33dcbda8ed7c6d603cab17bdb7f19", null ],
    [ "DMA_configTransfer", "group__dma__api.html#ga0aa51ed5155166eb9332bf6c2165ae92", null ],
    [ "DMA_configWrap", "group__dma__api.html#ga3bf1e97d735ac34a5dc04645227ee31a", null ]
];