var files_dup =
[
    [ "headers", "dir_7f57b1e41c5acd0e859ae5f3a2b075a9.html", "dir_7f57b1e41c5acd0e859ae5f3a2b075a9" ],
    [ "libraries", "dir_bc0718b08fb2015b8e59c47b2805f60c.html", "dir_bc0718b08fb2015b8e59c47b2805f60c" ],
    [ "sources", "dir_08d237fc27d4ecd563f71c5d52f2fecc.html", "dir_08d237fc27d4ecd563f71c5d52f2fecc" ],
    [ "src_device", "dir_feaa67ef983c77ad0c0254dfe2e07689.html", "dir_feaa67ef983c77ad0c0254dfe2e07689" ]
];