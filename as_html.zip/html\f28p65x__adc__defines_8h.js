var f28p65x__adc__defines_8h =
[
    [ "ADC_ADCA", "f28p65x__adc__defines_8h.html#a55f51e81e00e2333f8f14e3cb5691e41", null ],
    [ "ADC_ADCB", "f28p65x__adc__defines_8h.html#ace8e5c4caa41b0f3bbec58413114a863", null ],
    [ "ADC_ADCC", "f28p65x__adc__defines_8h.html#acd59f3f0403c63ab4f0b07b310648b87", null ],
    [ "ADC_BITOFFSET_TRIM_INDIVIDUAL", "f28p65x__adc__defines_8h.html#a099a782a8e1f07d92e72ecd664fb67e8", null ],
    [ "ADC_EXTERNAL", "f28p65x__adc__defines_8h.html#a3b478a7691eb5009de8a6f6108e4c2a1", null ],
    [ "ADC_INTERNAL", "f28p65x__adc__defines_8h.html#af62015ea449d000a38746d5f8cca2dd1", null ],
    [ "ADC_RESOLUTION_12BIT", "f28p65x__adc__defines_8h.html#ac1c41d620b2ca698d257aaa1f6de82e5", null ],
    [ "ADC_RESOLUTION_16BIT", "f28p65x__adc__defines_8h.html#a5c94e442b386d2611891e6c2bc9bd986", null ],
    [ "ADC_SIGNALMODE_DIFFERENTIAL", "f28p65x__adc__defines_8h.html#ac1358a2933aa8476189f77f390e067e3", null ],
    [ "ADC_SIGNALMODE_SINGLE", "f28p65x__adc__defines_8h.html#a646c11bc83ea2938bdf25e5ceae2acef", null ],
    [ "ADC_VREF2P5", "f28p65x__adc__defines_8h.html#a3dd8c6957d57c20ce74301c7a267d29f", null ],
    [ "ADC_VREF3P3", "f28p65x__adc__defines_8h.html#acc24c560d61de6f018eef7d494f8177b", null ]
];