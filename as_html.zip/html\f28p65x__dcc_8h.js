var f28p65x__dcc_8h =
[
    [ "DCCGCTRL_BITS", "struct_d_c_c_g_c_t_r_l___b_i_t_s.html", "struct_d_c_c_g_c_t_r_l___b_i_t_s" ],
    [ "DCCGCTRL_REG", "union_d_c_c_g_c_t_r_l___r_e_g.html", "union_d_c_c_g_c_t_r_l___r_e_g" ],
    [ "DCCCNTSEED0_BITS", "struct_d_c_c_c_n_t_s_e_e_d0___b_i_t_s.html", "struct_d_c_c_c_n_t_s_e_e_d0___b_i_t_s" ],
    [ "DCCCNTSEED0_REG", "union_d_c_c_c_n_t_s_e_e_d0___r_e_g.html", "union_d_c_c_c_n_t_s_e_e_d0___r_e_g" ],
    [ "DCCVALIDSEED0_BITS", "struct_d_c_c_v_a_l_i_d_s_e_e_d0___b_i_t_s.html", "struct_d_c_c_v_a_l_i_d_s_e_e_d0___b_i_t_s" ],
    [ "DCCVALIDSEED0_REG", "union_d_c_c_v_a_l_i_d_s_e_e_d0___r_e_g.html", "union_d_c_c_v_a_l_i_d_s_e_e_d0___r_e_g" ],
    [ "DCCCNTSEED1_BITS", "struct_d_c_c_c_n_t_s_e_e_d1___b_i_t_s.html", "struct_d_c_c_c_n_t_s_e_e_d1___b_i_t_s" ],
    [ "DCCCNTSEED1_REG", "union_d_c_c_c_n_t_s_e_e_d1___r_e_g.html", "union_d_c_c_c_n_t_s_e_e_d1___r_e_g" ],
    [ "DCCSTATUS_BITS", "struct_d_c_c_s_t_a_t_u_s___b_i_t_s.html", "struct_d_c_c_s_t_a_t_u_s___b_i_t_s" ],
    [ "DCCSTATUS_REG", "union_d_c_c_s_t_a_t_u_s___r_e_g.html", "union_d_c_c_s_t_a_t_u_s___r_e_g" ],
    [ "DCCCNT0_BITS", "struct_d_c_c_c_n_t0___b_i_t_s.html", "struct_d_c_c_c_n_t0___b_i_t_s" ],
    [ "DCCCNT0_REG", "union_d_c_c_c_n_t0___r_e_g.html", "union_d_c_c_c_n_t0___r_e_g" ],
    [ "DCCVALID0_BITS", "struct_d_c_c_v_a_l_i_d0___b_i_t_s.html", "struct_d_c_c_v_a_l_i_d0___b_i_t_s" ],
    [ "DCCVALID0_REG", "union_d_c_c_v_a_l_i_d0___r_e_g.html", "union_d_c_c_v_a_l_i_d0___r_e_g" ],
    [ "DCCCNT1_BITS", "struct_d_c_c_c_n_t1___b_i_t_s.html", "struct_d_c_c_c_n_t1___b_i_t_s" ],
    [ "DCCCNT1_REG", "union_d_c_c_c_n_t1___r_e_g.html", "union_d_c_c_c_n_t1___r_e_g" ],
    [ "DCCCLKSRC1_BITS", "struct_d_c_c_c_l_k_s_r_c1___b_i_t_s.html", "struct_d_c_c_c_l_k_s_r_c1___b_i_t_s" ],
    [ "DCCCLKSRC1_REG", "union_d_c_c_c_l_k_s_r_c1___r_e_g.html", "union_d_c_c_c_l_k_s_r_c1___r_e_g" ],
    [ "DCCCLKSRC0_BITS", "struct_d_c_c_c_l_k_s_r_c0___b_i_t_s.html", "struct_d_c_c_c_l_k_s_r_c0___b_i_t_s" ],
    [ "DCCCLKSRC0_REG", "union_d_c_c_c_l_k_s_r_c0___r_e_g.html", "union_d_c_c_c_l_k_s_r_c0___r_e_g" ],
    [ "DCC_REGS", "struct_d_c_c___r_e_g_s.html", "struct_d_c_c___r_e_g_s" ]
];