var f28p65x__xint_8h =
[
    [ "XINT1CR_BITS", "struct_x_i_n_t1_c_r___b_i_t_s.html", "struct_x_i_n_t1_c_r___b_i_t_s" ],
    [ "XINT1CR_REG", "union_x_i_n_t1_c_r___r_e_g.html", "union_x_i_n_t1_c_r___r_e_g" ],
    [ "XINT2CR_BITS", "struct_x_i_n_t2_c_r___b_i_t_s.html", "struct_x_i_n_t2_c_r___b_i_t_s" ],
    [ "XINT2CR_REG", "union_x_i_n_t2_c_r___r_e_g.html", "union_x_i_n_t2_c_r___r_e_g" ],
    [ "XINT3CR_BITS", "struct_x_i_n_t3_c_r___b_i_t_s.html", "struct_x_i_n_t3_c_r___b_i_t_s" ],
    [ "XINT3CR_REG", "union_x_i_n_t3_c_r___r_e_g.html", "union_x_i_n_t3_c_r___r_e_g" ],
    [ "XINT4CR_BITS", "struct_x_i_n_t4_c_r___b_i_t_s.html", "struct_x_i_n_t4_c_r___b_i_t_s" ],
    [ "XINT4CR_REG", "union_x_i_n_t4_c_r___r_e_g.html", "union_x_i_n_t4_c_r___r_e_g" ],
    [ "XINT5CR_BITS", "struct_x_i_n_t5_c_r___b_i_t_s.html", "struct_x_i_n_t5_c_r___b_i_t_s" ],
    [ "XINT5CR_REG", "union_x_i_n_t5_c_r___r_e_g.html", "union_x_i_n_t5_c_r___r_e_g" ],
    [ "XINT_REGS", "struct_x_i_n_t___r_e_g_s.html", "struct_x_i_n_t___r_e_g_s" ]
];