var dlog__4ch__f_8h =
[
    [ "DLOG_4CH_F", "struct_d_l_o_g__4_c_h___f.html", "struct_d_l_o_g__4_c_h___f" ],
    [ "DLOG_4CH_F_MACRO", "dlog__4ch__f_8h.html#a9bcfc53f1054070fe0f04c63a9c4a142", null ],
    [ "DLOG_4CH_F_FUNC", "dlog__4ch__f_8h.html#af9ec3c73c41de9205823ffcf6dd8b37b", null ],
    [ "DLOG_4CH_F_init", "dlog__4ch__f_8h.html#a95545b3796b7ed82199de7f5abb19e7b", null ]
];