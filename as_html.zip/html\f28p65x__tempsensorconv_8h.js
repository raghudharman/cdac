var f28p65x__tempsensorconv_8h =
[
    [ "GetTemperatureC", "f28p65x__tempsensorconv_8h.html#a07182860b4d40a90e148c78ac6081345", null ],
    [ "GetTemperatureK", "f28p65x__tempsensorconv_8h.html#afa8d52851974da4b34a28772188c5cef", null ],
    [ "InitTempSensor", "f28p65x__tempsensorconv_8h.html#a4ef8ff52dbced3027b8609c3d7871335", null ]
];