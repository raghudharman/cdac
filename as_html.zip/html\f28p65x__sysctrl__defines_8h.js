var f28p65x__sysctrl__defines_8h =
[
    [ "LPM_HALT", "f28p65x__sysctrl__defines_8h.html#a79df387c1758db6ab79e2f4d5a3dbfad", null ],
    [ "LPM_IDLE", "f28p65x__sysctrl__defines_8h.html#a2beb3489411ab07b842fcf2241477492", null ],
    [ "LPM_STANDBY", "f28p65x__sysctrl__defines_8h.html#ab5ecdc69271cab5aafa30f95a46e628e", null ]
];