var eqep_8c =
[
    [ "EQEP_setCompareConfig", "group__eqep__api.html#gaa8787d771e69ad29d74734ebe438d1d3", null ],
    [ "EQEP_setInputPolarity", "group__eqep__api.html#ga00c9bf4bd5ca0fcbb89948ec424904b3", null ]
];