var dir_511c0845e2c5571beb22e7b128418001 =
[
    [ "dataTypeDefinition.h", "data_type_definition_8h.html", "data_type_definition_8h" ],
    [ "drv8343.h", "drv8343_8h.html", "drv8343_8h" ],
    [ "drv8x_HAL.h", "drv8x___h_a_l_8h.html", "drv8x___h_a_l_8h" ]
];