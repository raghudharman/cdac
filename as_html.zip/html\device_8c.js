var device_8c =
[
    [ "__error__", "group__device__api.html#gad3489db107760a81e8a1382fe6ed6d61", null ],
    [ "Device_enableAllPeripherals", "group__device__api.html#gaa9e1606ed8be700f94337e534dbcd997", null ],
    [ "Device_init", "group__device__api.html#gada62d104647ffe50081171875dd795c0", null ],
    [ "Device_initGPIO", "group__device__api.html#ga9b36c48248e6fbfd869184f629f29c18", null ],
    [ "Device_verifyXTAL", "group__device__api.html#gaa2a6b61fc96ef9c240eef624a1d43c65", null ]
];