var f28p65x__dma_8h =
[
    [ "MODE_BITS", "struct_m_o_d_e___b_i_t_s.html", "struct_m_o_d_e___b_i_t_s" ],
    [ "MODE_REG", "union_m_o_d_e___r_e_g.html", "union_m_o_d_e___r_e_g" ],
    [ "CONTROL_BITS", "struct_c_o_n_t_r_o_l___b_i_t_s.html", "struct_c_o_n_t_r_o_l___b_i_t_s" ],
    [ "CONTROL_REG", "union_c_o_n_t_r_o_l___r_e_g.html", "union_c_o_n_t_r_o_l___r_e_g" ],
    [ "BURST_SIZE_BITS", "struct_b_u_r_s_t___s_i_z_e___b_i_t_s.html", "struct_b_u_r_s_t___s_i_z_e___b_i_t_s" ],
    [ "BURST_SIZE_REG", "union_b_u_r_s_t___s_i_z_e___r_e_g.html", "union_b_u_r_s_t___s_i_z_e___r_e_g" ],
    [ "BURST_COUNT_BITS", "struct_b_u_r_s_t___c_o_u_n_t___b_i_t_s.html", "struct_b_u_r_s_t___c_o_u_n_t___b_i_t_s" ],
    [ "BURST_COUNT_REG", "union_b_u_r_s_t___c_o_u_n_t___r_e_g.html", "union_b_u_r_s_t___c_o_u_n_t___r_e_g" ],
    [ "CH_REGS", "struct_c_h___r_e_g_s.html", "struct_c_h___r_e_g_s" ],
    [ "DMACTRL_BITS", "struct_d_m_a_c_t_r_l___b_i_t_s.html", "struct_d_m_a_c_t_r_l___b_i_t_s" ],
    [ "DMACTRL_REG", "union_d_m_a_c_t_r_l___r_e_g.html", "union_d_m_a_c_t_r_l___r_e_g" ],
    [ "DEBUGCTRL_BITS", "struct_d_e_b_u_g_c_t_r_l___b_i_t_s.html", "struct_d_e_b_u_g_c_t_r_l___b_i_t_s" ],
    [ "DEBUGCTRL_REG", "union_d_e_b_u_g_c_t_r_l___r_e_g.html", "union_d_e_b_u_g_c_t_r_l___r_e_g" ],
    [ "PRIORITYCTRL1_BITS", "struct_p_r_i_o_r_i_t_y_c_t_r_l1___b_i_t_s.html", "struct_p_r_i_o_r_i_t_y_c_t_r_l1___b_i_t_s" ],
    [ "PRIORITYCTRL1_REG", "union_p_r_i_o_r_i_t_y_c_t_r_l1___r_e_g.html", "union_p_r_i_o_r_i_t_y_c_t_r_l1___r_e_g" ],
    [ "PRIORITYSTAT_BITS", "struct_p_r_i_o_r_i_t_y_s_t_a_t___b_i_t_s.html", "struct_p_r_i_o_r_i_t_y_s_t_a_t___b_i_t_s" ],
    [ "PRIORITYSTAT_REG", "union_p_r_i_o_r_i_t_y_s_t_a_t___r_e_g.html", "union_p_r_i_o_r_i_t_y_s_t_a_t___r_e_g" ],
    [ "DMA_REGS", "struct_d_m_a___r_e_g_s.html", "struct_d_m_a___r_e_g_s" ]
];